package com.cts.stepdefinitions;

import java.util.concurrent.TimeUnit;

import org.openqa.selenium.WebDriver;
import org.openqa.selenium.chrome.ChromeDriver;

import io.cucumber.java.en.Given;
import io.cucumber.java.en.Then;
import io.cucumber.java.en.When;

public class StepDefinition {
	

	@When("enter username1 as {string} and I enter password as {string}")
	public void enter_username1_as_and_I_enter_password_as(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get access to page1")
	public void i_should_get_access_to_page1() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
	@When("enter username2 as {string} and I enter password as {string}")
	public void enter_username2_as_and_I_enter_password_as(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get access to page2")
	public void i_should_get_access_to_page2() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	

	@When("enter username3 as {string} and I enter password as {string}")
	public void enter_username3_as_and_I_enter_password_as(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get access to page3")
	public void i_should_get_access_to_page3() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	

	@When("enter username4 as {string} and I enter password as {string}")
	public void enter_username4_as_and_I_enter_password_as(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get access to page4")
	public void i_should_get_access_to_page4() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
	@When("I fill the details from excel {string} and sheet name {string}")
	public void i_fill_the_details_from_excel_and_sheet_name(String string, String string2) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get access to page5")
	public void i_should_get_access_to_page5() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}


	@When("I click on shop")
	public void i_click_on_shop() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("It should navigates to the products page")
	public void it_should_navigates_to_the_products_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	

	@When("I fill the details from excel\"\" and sheet name {string}")
	public void i_fill_the_details_from_excel_and_sheet_name(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get related search results")
	public void i_should_get_related_search_results() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
	@When("I select {string} from drop down")
	public void i_select_from_drop_down1(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get the books in high to low price order")
	public void i_should_get_the_books_in_high_to_low_price_order() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
	@When("I select {string} from drop down")
	public void i_select_from_drop_down(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get the books with high popularity at the top")
	public void i_should_get_the_books_with_high_popularity_at_the_top() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
	@When("I search the product as {string}")
	public void i_search_the_product_as(String string) {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get the message as No books found")
	public void i_should_get_the_message_as_No_books_found() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
	@When("I click on the add to basket button")
	public void i_click_on_the_add_to_basket_button() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Item should be added to the cart")
	public void item_should_be_added_to_the_cart() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}


	@When("I click on remove an item from the cart")
	public void i_click_on_remove_an_item_from_the_cart() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("Item should removed from the cart")
	public void item_should_removed_from_the_cart() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}


	@Then("It should navigate to the billing page")
	public void it_should_navigate_to_the_billing_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
	@Then("I should get data from excel")
	public void i_should_get_data_from_excel() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
	@When("I click on the place order")
	public void i_click_on_the_place_order() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get the message as orderplaced")
	public void i_should_get_the_message_as_orderplaced() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
	@When("I click on demo site")
	public void i_click_on_demo_site() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should navigates to that  demo page")
	public void i_should_navigates_to_that_demo_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	

	@When("I should enter the valid details and click on refresh")
	public void i_should_enter_the_valid_details_and_click_on_refresh() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get empty page")
	public void i_should_get_empty_page() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	

	@When("I hover to switchTo and click on window")
	public void i_hover_to_switchTo_and_click_on_window() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get a page with Frames&windows title")
	public void i_should_get_a_page_with_Frames_windows_title() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	

	@When("I hover to widgets and click on Datepicker")
	public void i_hover_to_widgets_and_click_on_Datepicker() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get a page with Datepicker title")
	public void i_should_get_a_page_with_Datepicker_title() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	
	@When("I hover to more and click on modals")
	public void i_hover_to_more_and_click_on_modals() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}

	@Then("I should get a page with Bootstrap modal")
	public void i_should_get_a_page_with_Bootstrap_modal() {
	    // Write code here that turns the phrase above into concrete actions
	    throw new io.cucumber.java.PendingException();
	}



}
		